#ifndef IAR_AMCL__BEAM_MODEL_NODE_HPP_
#define IAR_AMCL__BEAM_MODEL_NODE_HPP_
#include <string>
#include "nav2_amcl/pf/pf.hpp"
#include "nav2_amcl/pf/pf_pdf.hpp"
#include "nav2_amcl/map/map.hpp"
#include "nav2_amcl/sensors/laser/laser.hpp"

namespace iar_amcl
{
    /*
    * @class BeamModel
    * @brief Beam model laser sensor
    */
    class BeamModel : public nav2_amcl::Laser
    {
    public:
    /*
    * @brief BeamModel constructor
    */
    BeamModel(
        double z_hit, double z_short, double z_max, double z_rand, double sigma_hit,
        double lambda_short, double chi_outlier, size_t max_beams, map_t * map);

    /*
    * @brief Run a sensor update on laser
    * @param pf Particle filter to use
    * @param data Laser data to use
    * @return if it was succesful
    */
    bool sensorUpdate(pf_t * pf, nav2_amcl::LaserData * data);

    private:
    static double sensorFunction(nav2_amcl::LaserData * data, pf_sample_set_t * set);
    double z_short_;
    double z_max_;
    double lambda_short_;
    double chi_outlier_;
    };
}
#endif //IAR_AMCL__BEAM_MODEL_NODE_HPP_