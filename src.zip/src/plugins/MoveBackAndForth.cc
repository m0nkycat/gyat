#include <ignition/gazebo/System.hh>

class MoveBackAndForth : public ignition::gazebo::System, public ignition::gazebo::ISystemConfigure
{
    public: void Configure(const ignition::gazebo::Entity &_entity,
                           const std::shared_ptr<const sdf::Element> &_sdf,
                           ignition::gazebo::EntityComponentManager &_ecm,
                           ignition::gazebo::EventManager &_eventMgr) override
    {
        // Do nothing for now.
    }
};

IGNITION_ADD_PLUGIN(MoveBackAndForth, ignition::gazebo::System)

