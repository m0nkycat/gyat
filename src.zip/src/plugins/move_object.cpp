#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <ignition/math/Spline.hh>


class MoveObjectPlugin : public gazebo::ModelPlugin
{
public:
  void Load(gazebo::physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
  {
    // Store the pointer to the model
    model = _parent;

    // Create a connection to the Gazebo update event
    updateConnection = gazebo::event::Events::ConnectWorldUpdateBegin(
        std::bind(&MoveObjectPlugin::OnUpdate, this));
  }

  // Called by the Gazebo update event
  void OnUpdate()
  {
    // Get the current pose of the model
    gazebo::math::Pose pose = model->GetWorldPose();

    // Calculate a new X-coordinate to create a back-and-forth motion
    double newX = pose.pos.x + 0.01 * std::sin(pose.pos.x * 0.1);

    // Set the new pose of the model
    pose.pos.x = newX;
    model->SetWorldPose(pose);
  }

private:
  gazebo::physics::ModelPtr model;
  gazebo::event::ConnectionPtr updateConnection;
};

// Register this plugin with Gazebo
GZ_REGISTER_MODEL_PLUGIN(MoveObjectPlugin)

