#include <chrono>
#include <functional>
#include <memory>
#include <string>
#include <algorithm>
#include <vector>
#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

#define PI 3.14159265358

class PersonFollower : public rclcpp::Node
{
    public:
        PersonFollower() : Node("person_follower")
        {
            // TODO: Declare and initialize parameters for following distance, following angle, and control gains.
            // Set default values for these parameters.

            // Declare and init param 
            this->declare_parameter("following_distance", 0.2); 
            this->declare_parameter("following_angle", 0.0);  
            this->declare_parameter("angle_control_gain", 0.8);  
            this->declare_parameter("distance_control_gain", 0.5);

            // TODO: Get parameter values and save them to private class member variables.
            // retrieves the parameter values from the ROS 2 parameter server and stores them in private class member variables for later use.
            this->get_parameter("following_distance", following_distance_);
            this->get_parameter("following_angle", following_angle_);
            this->get_parameter("angle_control_gain", angle_control_gain_);
            this->get_parameter("distance_control_gain", distance_control_gain_);

            // TODO: Print parameter values for debugging.
            // This section prints the parameter values to the ROS 2 log for debugging and monitoring.
            RCLCPP_INFO(this->get_logger(), "following_distance: %f", following_distance_);
            RCLCPP_INFO(this->get_logger(), "following_angle: %f", following_angle_);
            RCLCPP_INFO(this->get_logger(), "angle_control_gain: %f", angle_control_gain_);
            RCLCPP_INFO(this->get_logger(), "distance_control_gain: %f", distance_control_gain_);

            // Publisher for the topic /cmd_vel
            // This creates a publisher for the /cmd_vel topic, which will be used to send control commands to the robot.
            this->cmd_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>(
                "/cmd_vel",
                rclcpp::SystemDefaultsQoS());

            using namespace std::placeholders;

            // Subscriber to the /scan topic
            this->scan_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
                "/scan",
                rclcpp::SensorDataQoS(),
                std::bind(&PersonFollower::scan_callback, this, _1));
        }

    private:
        // Define a command velocity publisher
        rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_publisher_;

        // Define a laser scan subscriber
        rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_subscriber_;

        // Laser scan topic message pointer
        sensor_msgs::msg::LaserScan::SharedPtr scan_;

        //Declare all private element variables to store parameters.
        // Parameters
        float following_distance_;        // The desired following distance from the person
        float following_angle_;           // The desired following angle relative to the robot's front
        float distance_control_gain_;     // Gain for distance control
        float angle_control_gain_;        // Gain for angle control

        void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg);
};

void PersonFollower::scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg)
{
    /*TODO
    1. Process the received scan_msg to get the location of the closest object in robot’s
    environment.
    NOTE: the four pillars of will be visible from the Lidar sensor, you have to remove the
    distance measurements of these four pillars by ignoring any measurement less than 0.2 meter.

    2. You have to calculate the bearing and the range of the closest object with respect to the
    robot frame. You have to check the LaserScan message definition, and how the Lidar sensor is mounted with respective to
    the robot’s coordinate.

    3. Write a Person Follow Reactive Control that takes the bearing and range information of the
    closest object in the environment as the input and publish a message on topic /cmd_vel to control the
    motion of the robot.
    */
    float closest_distance = 9999;
    float closest_angle = 9999;
    geometry_msgs::msg::Twist cmd_vel_msg;

       // Iterate through the range measurements in the scan message
        for (size_t i = 0; i < scan_msg->ranges.size(); ++i)
        {
            double range = scan_msg->ranges[i];

            // Ignore invalid range measurements and ranges less than 0.2 meters
            if (!std::isfinite(range) || range < 0.2)
            {
                continue;
            }

            // Calculate the angle of the current measurement in the robot's frame
            double angle = scan_msg->angle_min + scan_msg->angle_increment * i;

            // Update closest object information if a closer object is found
            if (range < closest_distance)
            {
                closest_distance = range;
                closest_angle = angle;
            }
        }

        float adjust = 90.0 * (3.14195/180);
        // Calculate control commands based on closest object information
        double linear_velocity = distance_control_gain_ * (closest_distance - following_distance_);
        double angular_velocity = angle_control_gain_ * ((closest_angle + adjust) - following_angle_);

        // Create and publish Twist message for controlling the robot
            cmd_vel_msg.linear.x = linear_velocity;
        cmd_vel_msg.angular.z = angular_velocity;

        cmd_vel_publisher_->publish(cmd_vel_msg);

}


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PersonFollower>());
    rclcpp::shutdown();
    return 0;
}