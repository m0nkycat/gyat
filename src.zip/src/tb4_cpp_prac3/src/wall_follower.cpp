#include <chrono>   // date and time utilities library
#include <functional>
#include <memory>
#include <string>
#include <algorithm>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"

#define PI 3.14159265358

class WallFollower : public rclcpp::Node
{
public:
    WallFollower(): Node("wall_follower")
    {
        // Parameter declaration and description
        auto wall_side_desc = rcl_interfaces::msg::ParameterDescriptor{};
        wall_side_desc.description = "A positive value indicates that the wall will be on the left side of the robot, otherwise on the right";
        auto buffer_zone_desc = rcl_interfaces::msg::ParameterDescriptor{};
        buffer_zone_desc.description = "A positive value used to determine whether the tracking control is on or off";
       
        this->declare_parameter<float>("following_distance", 0.9);
        this->declare_parameter<int8_t>("wall_side", 1, wall_side_desc);
        this->declare_parameter<float>("buffer_zone", 0.3, buffer_zone_desc);
        this->declare_parameter<float>("forward_velocity", 0.4);
        this->declare_parameter<float>("angle_control_gain_1", 0.8);
        this->declare_parameter<float>("angle_control_gain_2", 0.8);
        this->declare_parameter<float>("distance_control_gain", 0.5);
       
        // Getting parameter values
        this->get_parameter("following_distance", following_distance_);
        this->get_parameter("wall_side", wall_side_);
        this->get_parameter("buffer_zone", buffer_zone_);
        this->get_parameter("forward_velocity", forward_velocity_);
        this->get_parameter("angle_control_gain_1", angle_control_gain_1_);
        this->get_parameter("angle_control_gain_2", angle_control_gain_2_);
        this->get_parameter("distance_control_gain", distance_control_gain_);
        
        RCLCPP_INFO(this->get_logger(), "following_distance: %f", following_distance_);
        RCLCPP_INFO(this->get_logger(), "wall_side: %d", wall_side_);
        RCLCPP_INFO(this->get_logger(), "buffer_zone: %f", buffer_zone_);
        RCLCPP_INFO(this->get_logger(), "forward_velocity %f", forward_velocity_);
        RCLCPP_INFO(this->get_logger(), "angle_control_gain_1: %f", angle_control_gain_1_);
        RCLCPP_INFO(this->get_logger(), "angle_control_gain_2: %f", angle_control_gain_2_);
        RCLCPP_INFO(this->get_logger(), "distance_control_gain: %f", distance_control_gain_);
       
        // Setting the following_angle_ based on wall_side
        if(wall_side_ > 0)
            following_angle_ = PI/2;
        else
            following_angle_ = -PI/2;
       
        // Publisher and Subscriber creation
        this->cmd_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel", rclcpp::SystemDefaultsQoS());
        using namespace std::placeholders;
        this->scan_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>("/scan", rclcpp::SensorDataQoS(), std::bind(&WallFollower::scan_callback, this, _1));
    }

private:
    // Private member variables
    float following_distance_;
    int8_t wall_side_;
    float buffer_zone_;
    float following_angle_;
    float forward_velocity_;
    float angle_control_gain_1_;
    float angle_control_gain_2_;
    float distance_control_gain_;
   
    // Publisher and Subscriber
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_publisher_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_subscriber_;
   
    // Scan callback function
    void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg)
    {
        auto min_distance = std::min_element(scan_msg->ranges.begin(), scan_msg->ranges.end());
        float min_value = *min_distance;
        int min_index = std::distance(scan_msg->ranges.begin(), min_distance);
        float min_angle = (min_index - 320) * 2 * PI / 640.0;
       
        geometry_msgs::msg::Twist cmd_vel_msg;
       
        if(min_value < 12)
        {
            if(min_value > (following_distance_ + buffer_zone_))
            {
                if(abs(min_angle) > PI / 4.0)
                {
                    if(min_angle > PI / 4.0)
                        cmd_vel_msg.angular.z = 1.0;
                    else
                        cmd_vel_msg.angular.z = -1.0;
                }
                else
                {
                    cmd_vel_msg.angular.z = 0;
                    cmd_vel_msg.linear.x = forward_velocity_;
                }
            }
            else
            {
                float adjust = 90.0 * (3.14195/180);
                if(wall_side_ > 0)
                    cmd_vel_msg.angular.z = angle_control_gain_1_ * ((min_angle + adjust) - following_angle_) +
                                            angle_control_gain_2_ * (min_value - following_distance_);
                else
                    cmd_vel_msg.angular.z = angle_control_gain_1_ * ((min_angle + adjust) - following_angle_) -
                                            angle_control_gain_2_ * (min_value - following_distance_);
                cmd_vel_msg.linear.x = forward_velocity_ + distance_control_gain_ * (min_value - following_distance_);
            }
        }
        else
        {
            RCLCPP_INFO(this->get_logger(), "No Object is Detected");
            cmd_vel_msg.linear.x = 0.2;
        }
        cmd_vel_publisher_->publish(cmd_vel_msg);
    }
};

int main(int argc, char ** argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<WallFollower>());
    rclcpp::shutdown();
    return 0;
}