#ifndef IAR_AMCL__LIKELIHOOD_FIELD_NODE_HPP_
#define IAR_AMCL__LIKELIHOOD_FIELD_NODE_HPP_
#include <string>
#include "nav2_amcl/pf/pf.hpp"
#include "nav2_amcl/pf/pf_pdf.hpp"
#include "nav2_amcl/map/map.hpp"
#include "nav2_amcl/sensors/laser/laser.hpp"

namespace iar_amcl
{
    /*
    * @class LikelihoodFieldModel
    * @brief likelihood field model for laser sensor
    */
    class LikelihoodFieldModel : public nav2_amcl::Laser
    {
    public:
    /*
    * @brief LikelihoodFieldModel constructor
    */
    LikelihoodFieldModel(
        double z_hit, double z_max, double z_rand, double sigma_hit,
        double chi_outlier, size_t max_beams, map_t * map);

    /*
    * @brief Run a sensor update on laser
    * @param pf Particle filter to use
    * @param data Laser data to use
    * @return if it was succesful
    */
    bool sensorUpdate(pf_t * pf, nav2_amcl::LaserData * data);

    private:
    double max_occ_dist_;
    static double sensorFunction(nav2_amcl::LaserData * data, pf_sample_set_t * set);
    double z_max_;
    };
}
#endif //IAR_AMCL__LIKELIHOOD_FIELD_NODE_HPP_