
#include <math.h>
#include <assert.h>

#include "iar_amcl/likelihood_field_model.hpp"

namespace iar_amcl
{
    LikelihoodFieldModel::LikelihoodFieldModel(
    double z_hit, double z_max, double z_rand, double sigma_hit,
    double max_occ_dist, size_t max_beams, map_t * map)
    : Laser(max_beams, map)
    {
        z_hit_ = z_hit;
        z_rand_ = z_rand;
        sigma_hit_ = sigma_hit;
        z_max_ = z_max;
        // TODO #1 Uncommented following line of code, this line of code is used to update the likelihood field
        map_update_cspace(map, max_occ_dist);   //**
    }

    // Determine the probability for the given pose
    double
    LikelihoodFieldModel::sensorFunction(nav2_amcl::LaserData * data, pf_sample_set_t * set)
    {
        LikelihoodFieldModel * self;
        int i, j, step;
        double dist, pz; // z -
        double p; // probability (or weight) of indivdual particle
        double obs_range, obs_bearing; // the measurement values of one laser beam
        double total_weight;
        pf_sample_t * sample;
        pf_vector_t pose; //  the pose of the laser scanner position w.r.t the global frame

        // hit_x and hit_y are the horizontal position and vertical position of the endpoint of a laser
        double hit_x, hit_y;

        self = reinterpret_cast<LikelihoodFieldModel *>(data->laser);

        total_weight = 0.0;

        // Compute the sample weights
        for (j = 0; j < set->sample_count; j++) {
                sample = set->samples + j;
                pose = sample->pose;

                // TODO #2  Uncomment following line of code
                // This line of code takes account of the laser pose relative to the robot
                pose = pf_vector_coord_add(self->laser_pose_, pose);

                p = 1.0;

                step = (data->range_count - 1) / (self->max_beams_ - 1);
                // Step size normally larger than 1, but in case of error setting max number beams used
                // to model the probability, we need to check the step and ensure it is larger or equal to 1
                if (step<1)
                    step = 1;

                for (i = 0; i < data->range_count; i += step) {
                    obs_range = data->ranges[i][0];
                    obs_bearing = data->ranges[i][1];
                    pz = 0.0;

                    //TODO #3 implement the likelihood fiel sensor model
                    if (obs_range != obs_range) {
                        continue;
                    }

                    if (obs_range >= data->range_max) {
                        pz = self->z_max_;
                    }
                    else {
                        // Adding the random measurement component
                        pz += self->z_rand_ / data->range_max;

                        // Calculate the hit point in the world frame
                        hit_x = pose.v[0] + (obs_range * cos(pose.v[2] + obs_bearing));     //**
                        hit_y = pose.v[1] + (obs_range * sin(pose.v[2] + obs_bearing));     //**

                        // Convert the hit point to map coordinates
                        int mi = MAP_GXWX(self->map_, hit_x);
                        int mj = MAP_GYWY(self->map_, hit_y);
                        
                        if (!MAP_VALID(self->map_, mi, mj)) {                                      //**
                            dist = self->map_->max_occ_dist;                                       //**
                        } else {                                                                   //**
                            dist = self->map_->cells[MAP_INDEX(self->map_, mi, mj)].occ_dist;      //**
                        }
                        pz += self->z_hit_ * exp(-(dist * dist) / (2 * self->sigma_hit_ * self->sigma_hit_));

                        /*if (MAP_VALID(self->map_, mi, mj)) {
                            int map_idx = MAP_INDEX(self->map_, mi, mj);
                            if (self->map_->cells[map_idx].occ_state == 1) { // Check if the cell is occupied
                                dist = self->map_->cells[map_idx].occ_dist;
                            }
                        }*/
                    }
                    
                    assert(pz <= 1.0);
                    assert(pz >= 0.0);
                    //      p *= pz;
                    // here we have an ad-hoc weighting scheme for combining beam probs
                    // works well, though...
                    p += pz * pz * pz;
                }
            sample->weight *= p;
            total_weight += sample->weight;
        }
        return total_weight;
    }

    bool 
    LikelihoodFieldModel::sensorUpdate(pf_t * pf, nav2_amcl::LaserData * data)
    {
        if (max_beams_ < 2) {
            return false;
        }
        pf_update_sensor(pf, (pf_sensor_model_fn_t) sensorFunction, data);

        return true;
    }
}
